(() => {
  const form = document.querySelector('#eventQuote');
  const status = document.querySelector('#quoteStatus');
  const today = new Date();
  const localDate = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  form.elements.date.min = localDate;
  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const fields = new FormData(form);
    const value = key => String(fields.get(key) || '').trim();
    for (const key of ['name', 'venue', 'details']) {
      if (!value(key)) {
        status.textContent = 'Completa los campos obligatorios con tus datos.';
        form.elements[key].focus(); return;
      }
    }
    const rows = products.filter(p => cart[p.id]);
    const date = new Date(value('date') + 'T12:00:00').toLocaleDateString('es-MX');
    const lines = [
      'THE PIQUINS · SOLICITUD DE COTIZACIÓN', '',
      `Nombre: ${value('name')}`, '', 'DATOS DEL EVENTO',
      `Tipo: ${value('type')}`, `Fecha: ${date}`, `Lugar: ${value('venue')}`,
      `Presupuesto aproximado: ${money(Number(value('budget')))} MXN`,
      '', 'DESCRIPCIÓN', value('details'), '',
      'ARTÍCULOS SELECCIONADOS',
      ...(rows.length ? rows.map(p => `${cart[p.id]} × ${p.name} | ${p.id} | ${p.detail} | ${money(p.price)} c/u | ${money(p.price * cart[p.id])}`) : ['Sin artículos seleccionados. Solicito orientación según los detalles del evento.']),
      ...(rows.length ? ['', `Total ilustrativo de artículos: ${money(rows.reduce((sum,p) => sum+p.price*cart[p.id],0))} MXN`] : []),
      '', 'Precios de ejemplo, sujetos a confirmación. No incluye servicios adicionales. No confirma compra, pago ni reserva.',
      'Este archivo no ha sido enviado al negocio.'
    ];
    const url = URL.createObjectURL(new Blob(['\ufeff'+lines.join('\n')], {type:'text/plain;charset=utf-8'}));
    const link = document.createElement('a'); link.href=url; link.download='cotizacion-evento-piquins.txt';
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url),1000);
    status.textContent = 'Resumen generado con los datos de tu evento. Revisa tus descargas; todavía no se ha enviado al negocio.';
  });
})();
