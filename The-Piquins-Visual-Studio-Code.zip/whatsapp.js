'use strict';
// Número internacional del negocio, solo dígitos. Pendiente de configurar.
const WHATSAPP_NUMBER = '';
function buildWhatsAppOrderUrl(phone, items, customer, notes) {
  if (!/^[1-9]\d{7,14}$/.test(phone)) throw new Error('Falta configurar el número de WhatsApp del negocio.');
  if (!items.length) throw new Error('Agrega al menos un artículo al carrito.');
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const text = [
    'Hola, The Piquins. Quisiera consultar este pedido:',
    customer.trim() ? `Nombre: ${customer.trim()}` : '',
    '',
    ...items.map(item => `${item.quantity} × ${item.name}\n${item.detail} · ${item.id}\n${money(item.price)} c/u · Subtotal: ${money(item.price * item.quantity)}`),
    '',
    `Total estimado: ${money(total)} MXN`,
    notes.trim() ? `Notas: ${notes.trim()}` : '',
    '',
    'Catálogo de ejemplo. Por favor, confirmar precios y disponibilidad. Este mensaje no confirma una compra ni un pago.'
  ].filter(line => line !== undefined).join('\n');
  return `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
}
