/* Animación decorativa, sin sonido ni interacción con el catálogo. */
(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const canvas = document.createElement('canvas');
  canvas.className = 'mini-fireworks';
  canvas.setAttribute('aria-hidden', 'true');
  document.body.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  let width = 0, height = 0, frame = 0, last = 0, next = 0;
  let rockets = [], sparks = [];
  const colors = ['#ffe544', '#f35a3d', '#bde945', '#edabff'];
  function resize() {
    width = innerWidth; height = innerHeight;
    const ratio = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    canvas.style.width = width + 'px'; canvas.style.height = height + 'px';
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  }
  function launch() {
    const left = Math.random() > .5;
    const edge = width < 700 ? 18 : 28;
    rockets.push({ x: left ? edge : width - edge, y: height * .78,
      target: height * (.22 + Math.random() * .17), speed: 135 + Math.random() * 30,
      color: colors[Math.floor(Math.random() * colors.length)] });
  }
  function burst(rocket) {
    for (let i = 0; i < 18; i++) {
      const angle = Math.PI * 2 * i / 18;
      const speed = 20 + Math.random() * 42;
      sparks.push({ x: rocket.x, y: rocket.y, vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed, life: 1, color: i % 3 ? rocket.color : '#ffe544' });
    }
  }
  function tick(time) {
    const dt = Math.min((time - last) / 1000 || .016, .04); last = time;
    ctx.clearRect(0, 0, width, height);
    if (time > next) {
      // Pausar lanzamientos mientras el cliente revisa el carrito.
      if (!document.querySelector('dialog[open]')) launch();
      next = time + 3400 + Math.random() * 1800;
    }
    rockets = rockets.filter(r => {
      r.y -= r.speed * dt;
      if (r.y <= r.target) { burst(r); return false; }
      ctx.globalAlpha = .85;
      ctx.strokeStyle = '#ffc844'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(r.x, r.y + 7); ctx.lineTo(r.x, r.y + 19); ctx.stroke();
      ctx.fillStyle = '#ed4938'; ctx.fillRect(r.x - 3, r.y - 5, 6, 11);
      ctx.fillStyle = '#ffe044'; ctx.fillRect(r.x - 3, r.y, 6, 2);
      ctx.fillStyle = '#c93735'; ctx.beginPath();
      ctx.moveTo(r.x, r.y - 11); ctx.lineTo(r.x - 5, r.y - 5);
      ctx.lineTo(r.x + 5, r.y - 5); ctx.closePath(); ctx.fill();
      return true;
    });
    sparks = sparks.filter(s => {
      s.life -= dt * .75; if (s.life <= 0) return false;
      s.x += s.vx * dt; s.y += s.vy * dt; s.vy += 23 * dt;
      ctx.globalAlpha = Math.max(0, s.life) * .8;
      ctx.strokeStyle = s.color; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(s.x, s.y);
      ctx.lineTo(s.x - s.vx * .06, s.y - s.vy * .06); ctx.stroke();
      return true;
    });
    ctx.globalAlpha = 1; frame = requestAnimationFrame(tick);
  }
  function sync() {
    cancelAnimationFrame(frame); rockets = []; sparks = [];
    ctx.clearRect(0, 0, width, height);
    if (!reduced.matches && !document.hidden) {
      last = performance.now(); next = last + 600;
      frame = requestAnimationFrame(tick);
    }
  }
  addEventListener('resize', resize, { passive: true });
  document.addEventListener('visibilitychange', sync);
  reduced.addEventListener('change', sync);
  resize(); sync();
})();
